package com.agilebootcamp.tw.service;

public class OutOfStockException extends Exception {

	private static final long serialVersionUID = -9189227359543585074L;
}