package com.balazsholczer.tries;

public class Constant {

	public static final int ALPHABET_SIZE = 26;
}
