package com.balazsholczer.sorting;

public class InsertionSort {

}
