package com.balazsholczer.lru;

public class Constants {

	private Constants() {
		
	}
	
	public static final int CAPACITY = 4;
}
